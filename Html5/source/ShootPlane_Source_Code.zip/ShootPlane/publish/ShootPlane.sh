java -jar ShootPlane.jar
