Linux
chmod +x ShootPlane.sh
