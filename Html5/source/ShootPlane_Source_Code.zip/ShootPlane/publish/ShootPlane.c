#include <stdlib.h>
int main(int argc, char *argv[])
{
    system("java -jar ShootPlane.jar");
    return 0;
}